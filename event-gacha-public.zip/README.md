# イベントガチャ公開版
GitHub Pages用の3ファイルです。
- index.html
- gacha.html
- owner.html

Supabase Project URL: https://rosudqtzqadtvpzmeams.supabase.co
Publishable keyのみを使用しています。Secret/service_role keyは使用しません。

注意: 公開前にRLSをオーナー本人だけが管理できるよう厳密化してください。
